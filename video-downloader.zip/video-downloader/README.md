# Video Downloader App

Link paste karo, video/audio download karo.

## Stack
- Frontend: React + Vite + Tailwind + Capacitor
- Backend: Node.js + Express + yt-dlp
- AI: Transformers.js (translate + help)
- Build: GitHub Actions → APK

## Dev
Backend: `cd backend && npm install && npm start`
Frontend: `cd frontend && npm install && npm run dev`
