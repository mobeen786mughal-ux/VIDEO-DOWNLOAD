import { useState } from 'react';

export default function Downloader() {
  const [url, setUrl] = useState('');
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchInfo = async () => {
    if (!url) return;
    setLoading(true);
    try {
      // TODO: API_BASE env se aayega
      const res = await fetch('http://localhost:3000/api/info', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const data = await res.json();
      setInfo(data);
    } catch (err) {
      alert('Error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const download = async (formatId, type) => {
    try {
      const res = await fetch('http://localhost:3000/api/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url, formatId, type }),
      });
      // TODO: blob download logic
      alert('Download route hit. Logic pending.');
    } catch (err) {
      alert('Error: ' + err.message);
    }
  };

  return (
    <div className="space-y-4">
      <div className="glass-card p-5">
        <label className="block text-sm font-semibold mb-3 text-white/80">
          Video Link
        </label>
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://..."
          className="glow-input mb-4"
        />
        <button
          onClick={fetchInfo}
          disabled={loading || !url}
          className="glow-btn w-full disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? 'Fetching...' : 'Fetch Info'}
        </button>
      </div>

      {info && (
        <div className="glass-card p-5 space-y-4">
          <div className="text-sm text-white/80">
            <p className="font-semibold">{info.title || 'Video'}</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button className="glow-btn text-sm" onClick={() => download(null, 'video')}>
              ⬇ MP4 (Best)
            </button>
            <button className="glow-btn text-sm" onClick={() => download(null, 'audio')}>
              🎵 MP3
            </button>
          </div>

          <div className="pt-2">
            <p className="text-xs text-white/60 mb-2">Video Resolutions</p>
            <div className="grid grid-cols-3 gap-2">
              {['360p', '720p', '1080p'].map((r) => (
                <button
                  key={r}
                  onClick={() => download(r, 'video')}
                  className="py-2 rounded-xl bg-white/10 border border-white/20 text-sm font-semibold hover:bg-white/20 hover:shadow-[0_0_15px_rgba(168,85,247,0.5)] transition-all"
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
