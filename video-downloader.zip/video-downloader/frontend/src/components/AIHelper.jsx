import { useState } from 'react';

export default function AIHelper() {
  const [text, setText] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const translate = async () => {
    if (!text) return;
    setLoading(true);
    try {
      // TODO: @xenova/transformers se model load karna hai
      // const { pipeline } = await import('@xenova/transformers');
      // const t = await pipeline('translation', 'Xenova/opus-mt-en-ur');
      // const out = await t(text);
      setResult('[Translation model integration pending]');
    } catch (err) {
      setResult('Error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="glass-card p-5">
        <h2 className="text-lg font-bold mb-3">🤖 AI Helper</h2>
        <p className="text-xs text-white/60 mb-4">
          English → Urdu translate, ya app ke baare mein poochein
        </p>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Type something..."
          rows={4}
          className="glow-input mb-4 resize-none"
        />

        <button
          onClick={translate}
          disabled={loading || !text}
          className="glow-btn w-full disabled:opacity-50"
        >
          {loading ? 'Soch raha hoon...' : 'Translate / Ask'}
        </button>
      </div>

      {result && (
        <div className="glass-card p-5">
          <p className="text-xs text-white/60 mb-2">Result:</p>
          <p className="text-white">{result}</p>
        </div>
      )}
    </div>
  );
}
