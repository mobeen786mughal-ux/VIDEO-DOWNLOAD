import { useState } from 'react';
import Downloader from './components/Downloader.jsx';
import AIHelper from './components/AIHelper.jsx';

export default function App() {
  const [tab, setTab] = useState('download');

  return (
    <div className="min-h-screen p-5 flex flex-col max-w-md mx-auto">
      <header className="text-center py-6">
        <h1 className="text-4xl font-extrabold bg-gradient-to-r from-purple-400 via-pink-400 to-fuchsia-400 bg-clip-text text-transparent drop-shadow-[0_0_20px_rgba(168,85,247,0.6)]">
          Video Downloader
        </h1>
        <p className="text-white/60 mt-2 text-sm">Link paste karo, format choose karo</p>
      </header>

      <nav className="glass-card p-2 flex gap-2 mb-5">
        <button
          onClick={() => setTab('download')}
          className={`flex-1 py-3 rounded-xl font-semibold transition-all ${
            tab === 'download'
              ? 'bg-gradient-to-r from-purple-500 to-pink-500 shadow-[0_0_20px_rgba(168,85,247,0.6)]'
              : 'text-white/60'
          }`}
        >
          Download
        </button>
        <button
          onClick={() => setTab('ai')}
          className={`flex-1 py-3 rounded-xl font-semibold transition-all ${
            tab === 'ai'
              ? 'bg-gradient-to-r from-purple-500 to-pink-500 shadow-[0_0_20px_rgba(168,85,247,0.6)]'
              : 'text-white/60'
          }`}
        >
          AI Help
        </button>
      </nav>

      <main className="flex-1">
        {tab === 'download' ? <Downloader /> : <AIHelper />}
      </main>

      <footer className="text-center text-white/40 text-xs py-5">
        Personal use only • v0.1
      </footer>
    </div>
  );
}
