require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { YtDlp } = require('ytdlp-nodejs');

const app = express();
const ytdlp = new YtDlp();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ status: 'ok', message: 'Video Downloader API running' });
});

// TODO: /api/info - video metadata fetch
app.post('/api/info', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: 'URL required' });
    // Logic baad mein
    res.json({ message: 'info route ready', url });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// TODO: /api/download - stream file
app.post('/api/download', async (req, res) => {
  try {
    const { url, formatId, type } = req.body;
    if (!url) return res.status(400).json({ error: 'URL required' });
    // Logic baad mein
    res.json({ message: 'download route ready', url, formatId, type });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => console.log(`✅ Server: http://localhost:${PORT}`));
